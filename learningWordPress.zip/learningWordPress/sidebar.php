<!--Secondary column-->
		<div class="secondary-column">
			<?php dynamic_sidebar('sidebar1'); ?>

		</div>
		<!--End of Secondary column-->