<?php 

get_header();

if (have_posts()):
	while (have_posts()) : the_post(); ?>
	
	<article class="post">

		<!-- post thumbnail-->
		<div class="post-thumbnails">		
			<a href="<?php the_permalink()?>"><?php  the_post_thumbnail('banner-image');?></a>		
		</div> <!-- post thumbnail-->
		<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		


		<h5 class="post-info"><?php the_time('F jS, Y');?> | By <a href="<?php get_author_posts_url(get_the_author_meta('ID'));?>"><?php the_author(); ?> </a> | Posted in 
			<?php 
			
			$categories = get_the_category();
			$separator = ", ";
			$output = '';

			if($categories){

				foreach ($categories as $category) {
					
					$output .= '<a href="'. get_category_link($category) .'">'. $category->cat_name . '</a>' . $separator;
				}
				echo trim($output, $separator);
			}

			
			?></h5>
			
		

		<?php the_content(); ?>

		<!--About author box-->
		<div class="about-author clearfix">
			<div class="about-author-image">
				<?php echo get_avatar(get_the_author_meta('ID'), 512);?>
				<p><?php echo get_the_author_meta('nickname');?></p>
			</div>

			<?php $otherAuthorPost = new WP_Query(array(
				'author' => get_the_author_meta('ID'),
				'posts_per_page' => 3,
				'post__not_in'=> array(get_the_ID()) 
			));?>

			<div class="about-author-text">
				<h3>About the author</h3>
				<?php echo wpautop(get_the_author_meta('description')); ?>

				<?php if ($otherAuthorPost->have_posts()) { ?>
				<div class="other-posts-by">
					<h4>Others posts by: <?php echo get_the_author_meta('nickname'); ?></h4>
					<ul>
						<?php while ( $otherAuthorPost->have_posts()) {
							$otherAuthorPost->the_post(); ?>
							<li><a href="<?php the_permalink(); ?>"><?php the_title();?></a></li>
						<?php } ?>
					</ul>
				</div>
				<?php } wp_reset_postdata()?>
				<?php if (count_user_posts(get_the_author_meta('ID')) > 3) { ?>
				<a class="btn" href="<?php echo get_author_posts_url(get_the_author_meta('ID'))?>">View all posts by: <?php echo get_the_author_meta('nickname')?></a>
			<?php } ?>
			</div>
		</div>
		<!--End of about author box-->

		<!-- Comments area -->
		<div id="comments-area">
				
					<?php comments_template();?>
				
		</div><!-- #comments-area -->
	</article>

	<?php endwhile;

	else :
		echo'<p> No content found</p>';

	endif;

get_footer();
?>