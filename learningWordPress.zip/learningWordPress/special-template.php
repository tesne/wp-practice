<?php 

/* 
Template name: Especial layout
*/

get_header();

	if (have_posts()):
		while (have_posts()): the_post(); ?>
	
		<article class="post-page">
			<div class="column-container clearfix">
				<div class="title-column">
					<h2><?php the_title();?></h2>
				</div>
				<!-- Info box-->
				<div class="info-box">
					<h4>Disclaimer Title</h4>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit amet mattis eros</p>
				</div><!--/Info box-->
				
				<?php the_content();?>
				
			</div>
		</article>	

			<?php endwhile;
			else:
				echo '<p>No content found</p>';
			endif;
			

	get_footer();
?>
