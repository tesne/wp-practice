<?php 

get_header();?>
	<h2> Particular heading</h2>
	 <?php if (have_posts()):
		while (have_posts()): the_post();
	
		the_content();

		endwhile;
		else:
			echo '<p>No content found</p>';

		endif; ?>
	<h2> Other heading</h2>

	 <?php if (have_posts()):
			while (have_posts()): the_post();
		
			the_content();

			endwhile;
			else:
				echo '<p>No content found</p>';

			endif; ?>
			<!-- home columns-->
			<div class="home-columns clearfix">
				<div class="one-half">
					<?php 
						//opinion posts loop begins here
						$opinionPosts = new WP_Query('cat=4&posts_per_page=2&orderby=title&order=ASC');

						if ($opinionPosts->have_posts()):
							while ($opinionPosts->have_posts()): $opinionPosts->the_post(); ?>
						
							<h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
							<?php the_excerpt();?>
							<?php endwhile;
							else:
								echo '<p>No content found</p>';

						endif; 
						wp_reset_postdata();
						//end of opinion posts loop
					?>	
				</div>
				<div class="one-half last">
					<?php
						//News post loop begins here

						$newsPosts = new WP_Query('cat=1&posts_per_page=2');

						if ($newsPosts->have_posts()):
							while ($newsPosts->have_posts()): $newsPosts->the_post(); ?>
						
							<h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
							<?php the_excerpt();?>

							<?php endwhile;
							else:
								echo '<p>No content found</p>';

						endif; 
						wp_reset_postdata();
					?>
				</div>
			</div>


<?php
get_footer();

?>
