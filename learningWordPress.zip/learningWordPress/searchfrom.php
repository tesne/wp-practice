<form role="search" method="get" id="searchform" action="<?php echo home_url('/')?>">
	<div><label class="screen-reader-text" for="s">Search form:</label>
		<input type="text" name="s" id="s" value="">
		<input type="submit" id="searchsubmit" value="Search" placeholder="<?php the_search_query();?>">
	</div>	
</form>