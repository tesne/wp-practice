<?php 
/* 
Template name: Page portfolio
*/
get_header();

	if (have_posts()):
		while (have_posts()): the_post(); ?>
	
		<article class="post-page">
			
			
				
			<!--Column container-->
			<div class="column-container clearfix">
				<!--title colunm-->	
				<div class="title-column">
					<h2><?php the_title();?></h2>
				</div><!--/titlecolunm-->
				
				<!-- text colunm-->
				<div class="text-column">
					<?php the_content();?>
				</div><!--/tex colunm-->
			</div><!--/Colunm container-->		
		</article>	

			<?php endwhile;
			else:
				echo '<p>No content found</p>';
			endif;
			

	get_footer();
?>
