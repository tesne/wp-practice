<?php 

get_header(); ?>

	<!--Site content-->
	<div class="site-content clearfix">
		<!--Main column -->
		<div class="main-column">
		<!-- End of Main column-->

		<?php if (have_posts()):
			while (have_posts()) : the_post(); 
			
			get_template_part('content', get_post_format());

			endwhile;

			echo paginate_links();

			else :
				echo'<p> No content found</p>';

			endif; ?>
		</div>
		
		<?php get_sidebar();?>
		
	</div>
	<!--End of site content-->
<?php get_footer();
?>