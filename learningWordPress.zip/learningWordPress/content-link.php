<article class="post post-link">
	<a href="<?php echo get_the_content();?>"><?php the_title();?></a>
</article>