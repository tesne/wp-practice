<footer id="main-footer">
			
			<div class="footer-copyright">
				&copy; <?php echo date('Y');?> <?php bloginfo('name');?>
				
			</div><!-- /.footer-copyright -->
			
		</footer><!-- footer -->
	
	</div><!-- /#global-container -->

	
</body>
</html>